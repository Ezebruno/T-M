<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>T&M - Iniciar Sesión</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="shortcut icon" href="img/LOGO T&M.jpg" type="image/x-icon">
</head>
<body>
  <main class="login-container">
    <h1>Iniciar Sesión</h1>
    
    <?php if (isset($_GET['error'])): ?>
      <div class="alert error">Credenciales incorrectas</div>
    <?php endif; ?>
    
    <?php if (isset($_GET['registro'])): ?>
      <div class="alert success">¡Registro exitoso! Por favor ingrese</div>
    <?php endif; ?>
    
    <form action="php/login.php" method="post" class="login-form">
      <div class="form-group">
        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" required
          value="<?php echo isset($_COOKIE['dni']) ? htmlspecialchars($_COOKIE['dni']) : ''; ?>">
      </div>
      
      <div class="form-group">
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required
          value="<?php echo isset($_COOKIE['password']) ? htmlspecialchars($_COOKIE['password']) : ''; ?>">
      </div>

      <div class="form-group checkbox">
        <input type="checkbox" id="recordarme" name="recordarme"
          <?php echo (isset($_COOKIE['dni']) && isset($_COOKIE['password'])) ? 'checked' : ''; ?>>
        <label for="recordarme">Recordarme</label>
      </div>
      <button type="submit" class="btn">Ingresar</button>
    
      <p class="recuperar-contrasena"><a href="php/recuperar_contrasena.php">¿Olvidaste tu contraseña?</a></p>
    </form>
    
    <p class="register-link">¿No tienes cuenta? <a href="register.php">Regístrate aquí</a></p>
  </main>
</body>
</html>
