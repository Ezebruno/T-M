<?php
session_start();

// Verificación robusta de sesión
if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'empleado') {
    header("HTTP/1.1 403 Forbidden");
    exit('<div class="error">Acceso no autorizado. Redireccionando... 
          <script>setTimeout(()=>window.location.href="index.php", 2000)</script></div>');
}

require_once "conexion.php";

// Obtener filtros
$id = $_SESSION['id'];
$mes = isset($_GET['mes']) ? intval($_GET['mes']) : null;
$anio = isset($_GET['anio']) ? intval($_GET['anio']) : null;

// Construir la consulta
$query = "SELECT id, fecha, archivo FROM recibos WHERE empleado_id = ?";
$params = [$id];
$types = "i";

if ($mes) {
    $query .= " AND MONTH(fecha) = ?";
    $params[] = $mes;
    $types .= "i";
}
if ($anio) {
    $query .= " AND YEAR(fecha) = ?";
    $params[] = $anio;
    $types .= "i";
}

$query .= " ORDER BY fecha DESC";

$stmt = mysqli_prepare($conexion, $query);
mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Recibos de Sueldo</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .form-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }
        
        select, input[type="number"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: inherit;
        }
        
        .btn {
            display: inline-block;
            padding: 0.85rem 2.5rem;
            background: #4a6fa5;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #3a5a8a;
        }
        
        .btn-secondary {
            background: #6c757d;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .btn-download {
            background: #28a745;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            color: white;
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .btn-download:hover {
            background: #218838;
        }
        
        .receipts-list {
            margin: 1.5rem 0;
        }
        
        .receipt-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            border-bottom: 1px solid #eee;
            transition: background 0.2s;
        }
        
        .receipt-item:hover {
            background-color: #f8f9fa;
        }
        
        .receipt-date {
            color: #555;
            font-weight: 500;
        }
        
        .no-receipts {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
        }
        
        .filter-form {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            align-items: flex-end;
            margin-bottom: 1.5rem;
        }
        
        .filter-group {
            flex: 1;
            min-width: 150px;
        }
        
        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: space-between;
        }

        .form-actions .btn {
            flex: 1;
            text-align: center;
        }
        
        .icon {
            margin-right: 0.5rem;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <h1><i class="fas fa-file-invoice-dollar icon"></i> Mis Recibos de Sueldo</h1>
        </header>
        
        <main class="dashboard-main">
            <div class="form-container">
                <!-- Filtro por mes y año -->
                <form method="GET" class="filter-form">
                    <div class="form-group filter-group">
                        <label for="mes">Mes</label>
                        <select name="mes" id="mes">
                            <option value="">Todos los meses</option>
                            <?php
                            for ($i = 1; $i <= 12; $i++) {
                                $selected = ($mes === $i) ? 'selected' : '';
                                $nombre_mes = strftime('%B', mktime(0, 0, 0, $i, 10));
                                echo "<option value=\"$i\" $selected>$nombre_mes</option>";
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="form-group filter-group">
                        <label for="anio">Año</label>
                        <input type="number" name="anio" id="anio" 
                               placeholder="Ej: 2025" min="2000" max="2100" 
                               value="<?= htmlspecialchars($anio ?? '') ?>">
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn">
                            <i class="fas fa-search icon"></i> Buscar
                        </button>
                    </div>
                </form>

                <div class="receipts-list">
                    <?php if (mysqli_num_rows($result) === 0): ?>
                        <div class="no-receipts">
                            <i class="fas fa-info-circle" style="font-size: 2rem; margin-bottom: 1rem;"></i>
                            <p>No hay recibos disponibles para los filtros seleccionados</p>
                        </div>
                    <?php else: ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <div class="receipt-item">
                                <div class="receipt-date">
                                    <i class="fas fa-calendar-alt icon"></i> 
                                    <?= htmlspecialchars(date('d/m/Y', strtotime($row['fecha']))) ?>
                                </div>
                                <a href="../recibos/<?= htmlspecialchars(basename($row['archivo'])) ?>" 
                                   class="btn-download"
                                   download="recibo_<?= htmlspecialchars(date('Y-m-d', strtotime($row['fecha']))) ?>.pdf">
                                   <i class="fas fa-download icon"></i> Descargar
                                </a>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>

                <div class="form-actions">
                    <a href="dashboard.php" class="btn btn-secondary">Volver al Panel
                    </a>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
<?php
mysqli_stmt_close($stmt);
mysqli_close($conexion);
?>