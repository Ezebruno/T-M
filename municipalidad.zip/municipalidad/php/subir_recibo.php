<?php
session_start();

// Verificación robusta de sesión y rol
if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'admin') {
    header("HTTP/1.1 403 Forbidden");
    exit('<div class="error">Acceso no autorizado. Redireccionando... 
          <script>setTimeout(()=>window.location.href="index.php", 2000)</script></div>');
}

require_once "conexion.php";

// Procesar formulario
$uploadSuccess = false;
$errorMsg = '';
$results = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['archivos_pdf'])) {
    $fecha = DateTime::createFromFormat('Y-m-d', $_POST['fecha']);
    
    if (!$fecha) {
        $errorMsg = "Formato de fecha incorrecto (YYYY-MM-DD)";
    } else {
        // Obtener lista de empleados por DNI
        $empleados = [];
        $res = $conexion->query("SELECT id, dni FROM empleados");
        while ($row = $res->fetch_assoc()) {
            $empleados[$row['dni']] = $row['id'];
        }

        foreach ($_FILES['archivos_pdf']['name'] as $index => $name) {
            if ($_FILES['archivos_pdf']['error'][$index] !== UPLOAD_ERR_OK) {
                $results[$name] = "Error al subir el archivo";
                continue;
            }

            $tmpName = $_FILES['archivos_pdf']['tmp_name'][$index];
            $fileType = mime_content_type($tmpName);
            if ($fileType !== 'application/pdf') {
                $results[$name] = "No es un archivo PDF válido";
                continue;
            }

            $dni = pathinfo($name, PATHINFO_FILENAME);
            if (!isset($empleados[$dni])) {
                $results[$name] = "No existe empleado con DNI $dni";
                continue;
            }

            $empleado_id = $empleados[$dni];
            $nombreArchivo = 'recibo_' . $empleado_id . '_' . date('Ymd_His') . '_' . uniqid() . '.pdf';
            $destino = "../recibos/" . $nombreArchivo;

            if (move_uploaded_file($tmpName, $destino)) {
                $stmt = $conexion->prepare("INSERT INTO recibos (empleado_id, archivo, fecha) VALUES (?, ?, ?)");
                $stmt->bind_param("iss", $empleado_id, $nombreArchivo, $_POST['fecha']);

                if ($stmt->execute()) {
                    $results[$name] = "Éxito";
                    $uploadSuccess = true;
                } else {
                    @unlink($destino);
                    $results[$name] = "Error al registrar en BD";
                }
            } else {
                $results[$name] = "Error al mover el archivo";
            }
        }

        // Registrar acción
        if ($uploadSuccess) {
            error_log("Recibos masivos subidos por admin {$_SESSION['id']}: " . 
                      count(array_filter($results, fn($r) => $r === "Éxito")) . " archivos procesados");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Subir Recibos de Sueldo</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .upload-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .file-input {
            border: 2px dashed #ddd;
            padding: 1.5rem;
            text-align: center;
        }
        .btn {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
        }
        .btn:hover {
            background-color: #218838;
        }
        .alert {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .results-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        .results-table th, .results-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .results-table th {
            background-color: #f2f2f2;
        }
        .success-row {
            background-color: #e6ffe6;
        }
        .error-row {
            background-color: #ffe6e6;
        }
        .instructions {
            background-color: #f8f9fa;
            border-left: 4px solid #17a2b8;
            padding: 1rem;
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="upload-container">
        <h1><i class="fas fa-folder-open"></i> Subir Recibos de Sueldo</h1>
        
        <?php if ($uploadSuccess): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> Proceso completado. Verifique los resultados abajo.
            </div>
        <?php elseif ($errorMsg): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($errorMsg) ?>
            </div>
        <?php endif; ?>
        
        <div class="instructions">
            <h3><i class="fas fa-info-circle"></i> Instrucciones:</h3>
            <ol>
                <li>Cree una carpeta con todos los recibos de sueldo en formato PDF.</li>
                <li>Cada archivo debe estar nombrado con el <strong>DNI</strong> del empleado (ej: <code>12345678.pdf</code>).</li>
                <li>Seleccione la carpeta desde el botón de carga.</li>
                <li>El sistema asignará automáticamente cada recibo al empleado correspondiente.</li>
            </ol>
        </div>
        
        <form method="post" enctype="multipart/form-data" class="upload-form">
            <div class="form-group">
                <label for="fecha">Fecha de los Recibos:</label>
                <input type="date" id="fecha" name="fecha" class="form-control" required
                       value="<?= htmlspecialchars($_POST['fecha'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label>Carpeta con Recibos PDF:</label>
                <div class="file-input">
                    <input type="file" name="archivos_pdf[]" webkitdirectory multiple accept="application/pdf" required>
                    <p class="small">Seleccione una carpeta. Todos los archivos deben ser PDF y nombrados con DNI.</p>
                </div>
            </div>
            
            <button type="submit" class="btn">
                <i class="fas fa-upload"></i> Subir Recibos
            </button>
            <a href="dashboard.php" class="btn" style="background-color: #6c757d; margin-left: 10px; text-decoration: none;">
                <i class="fas fa-home"></i> Volver al Menú
            </a>
        </form>
        
        <?php if (!empty($results)): ?>
            <h3>Resultados del Procesamiento:</h3>
            <table class="results-table">
                <thead>
                    <tr>
                        <th>Archivo</th>
                        <th>Resultado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $file => $result): ?>
                        <tr class="<?= $result === 'Éxito' ? 'success-row' : 'error-row' ?>">
                            <td><?= htmlspecialchars($file) ?></td>
                            <td><?= htmlspecialchars($result) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>
<?php
$conexion->close();
?>
