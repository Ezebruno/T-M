<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recuperar Contraseña - T&M</title>
  <link rel="stylesheet" href="../css/style.css">
  <link rel="shortcut icon" href="img/LOGO T&M.jpg" type="image/x-icon">
</head>
<body>
  <main class="login-container">
    <h1>Recuperar Contraseña</h1>

    <?php if (isset($_GET['error'])): ?>
      <div class="alert error">No se encontró el usuario</div>
    <?php endif; ?>

    <?php if (isset($_GET['enviado'])): ?>
      <div class="alert success">Se ha enviado un enlace de recuperación al correo registrado</div>
    <?php endif; ?>

    <form action="php/send-reset.php" method="post" class="login-form">
      <div class="form-group">
        <label for="identifier">DNI o Correo electrónico:</label>
        <input type="text" id="identifier" name="identifier" required>
      </div>

      <button type="submit" class="btn">Enviar enlace de recuperación</button>
    </form>

    <p class="register-link"><a href="../index.php">Volver a Iniciar Sesión</a></p>
  </main>
</body>
</html>
