<?php
session_start();

if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'admin') {
    header("HTTP/1.1 403 Forbidden");
    exit('<div class="error">Acceso no autorizado. Redireccionando... 
          <script>setTimeout(()=>window.location.href="index.php", 2000)</script></div>');
}

require_once "conexion.php";

// Aprobación
if (isset($_GET['aprobar'])) {
    $id = filter_var($_GET['aprobar'], FILTER_VALIDATE_INT);
    if ($id) {
        $stmt = $conexion->prepare("UPDATE pedidos_indumentaria 
                                   SET estado = 'aprobado', 
                                       aprobado_por = ?, 
                                       fecha_aprobacion = NOW() 
                                   WHERE id = ?");
        $stmt->bind_param("ii", $_SESSION['id'], $id);
        $stmt->execute();

        error_log("Pedido $id aprobado por admin {$_SESSION['id']}");
        $_SESSION['msg'] = "✅ Pedido $id aprobado correctamente.";
        header("Location: gestionar_indumentaria.php");
        exit;
    }
}

// Rechazo
if (isset($_GET['rechazar'])) {
    $id = filter_var($_GET['rechazar'], FILTER_VALIDATE_INT);
    if ($id) {
        $stmt = $conexion->prepare("UPDATE pedidos_indumentaria 
                                   SET estado = 'rechazado', 
                                       aprobado_por = ?, 
                                       fecha_aprobacion = NOW() 
                                   WHERE id = ?");
        $stmt->bind_param("ii", $_SESSION['id'], $id);
        $stmt->execute();

        error_log("Pedido $id rechazado por admin {$_SESSION['id']}");
        $_SESSION['msg'] = "❌ Pedido $id rechazado correctamente.";
        header("Location: gestionar_indumentaria.php");
        exit;
    }
}

// Obtener pedidos
$query = "SELECT p.id, e.nombre, e.dni, p.mensaje, p.fecha_pedido, p.estado,
                 p.aprobado_por, p.fecha_aprobacion
          FROM pedidos_indumentaria p
          JOIN empleados e ON p.empleado_id = e.id
          ORDER BY 
            CASE p.estado 
                WHEN 'pendiente' THEN 1
                WHEN 'aprobado' THEN 2
                WHEN 'rechazado' THEN 3
            END,
            p.fecha_pedido DESC";
$result = $conexion->query($query);

// Mensajes
$msg = '';
if (isset($_SESSION['msg'])) {
    $msg = $_SESSION['msg'];
    unset($_SESSION['msg']);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Indumentaria</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        <?php // Estilos compartidos del primer archivo ?>
        body {
            background: url('../img/fondo.png') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 2rem;
        }
        .upload-container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 1.5rem;
        }
        .alert {
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1.5rem;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .pedido-card {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            background: #fff;
        }
        .pedido-header {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px;
        }
        .pedido-header h3 {
            margin: 0;
        }
        .pedido-info {
            margin-top: 0.75rem;
            font-size: 0.9rem;
            color: #555;
        }
        .pedido-mensaje {
            margin-top: 1rem;
            background-color: #f8f9fa;
            padding: 1rem;
            border-left: 4px solid #17a2b8;
        }
        .pedido-actions {
            margin-top: 1.5rem;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .btn {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 0.6rem 1.2rem;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            text-decoration: none;
        }
        .btn-container {
            text-align: center;
            margin-top: 2rem;
        }

        .btn-back {
            font-size: 1.2rem;       /* Texto más grande */
            padding: 10px 22px;      /* Más espacio interno */
            min-width: 200px;        /* Ancho mínimo mayor */
        }


        .btn:hover {
            background-color: #218838;
        }
        .btn-reject {
            background-color: #dc3545;
        }
        .btn-reject:hover {
            background-color: #c82333;
        }
        .badge {
            display: inline-block;
            padding: 0.3rem 0.6rem;
            font-size: 0.8rem;
            font-weight: 600;
            border-radius: 12px;
        }
        .badge-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        .badge-approved {
            background-color: #d4edda;
            color: #155724;
        }
        .badge-rejected {
            background-color: #f8d7da;
            color: #721c24;
        }
        .btn-back {
            background-color: #6c757d;
            margin-top: 2rem;
        }
        .btn-back:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <div class="upload-container">
        <h1><i class="fas fa-tshirt"></i> Gestión de Indumentaria</h1>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <?php if ($result->num_rows === 0): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> No hay pedidos registrados.
            </div>
        <?php else: ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="pedido-card">
                    <div class="pedido-header">
                        <h3><?= htmlspecialchars($row['nombre']) ?> (DNI: <?= htmlspecialchars($row['dni']) ?>)</h3>
                        <span class="badge badge-<?= $row['estado'] ?>">
                            <?= ucfirst($row['estado']) ?>
                        </span>
                    </div>
                    <div class="pedido-info">
                        <p><strong>Fecha del pedido:</strong> <?= htmlspecialchars($row['fecha_pedido']) ?></p>
                        <?php if ($row['estado'] !== 'pendiente'): ?>
                            <p><strong>Procesado el:</strong> <?= htmlspecialchars($row['fecha_aprobacion']) ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="pedido-mensaje">
                        <strong>Mensaje:</strong>
                        <p><?= nl2br(htmlspecialchars($row['mensaje'])) ?></p>
                    </div>
                    <?php if ($row['estado'] === 'pendiente'): ?>
                        <div class="pedido-actions">
                            <a class="btn" href="?aprobar=<?= $row['id'] ?>"><i class="fas fa-check-circle"></i> Aprobar</a>
                            <a class="btn btn-reject" href="?rechazar=<?= $row['id'] ?>"><i class="fas fa-times-circle"></i> Rechazar</a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>

        <div class="btn-container">
            <a href="dashboard.php" class="btn btn-back">
                <i class="fas fa-home"></i> Volver al Menú
            </a>
        </div>

    </div>
</body>
</html>
<?php $conexion->close(); ?>
