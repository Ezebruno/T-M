<?php
session_start();
include("conexion.php");

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../register.php?error=Método no permitido");
    exit();
}

// Validar campos obligatorios
$required_fields = ['dni', 'nombre', 'password', 'confirm_password'];
foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        header("Location: ../register.php?error=Todos los campos son obligatorios");
        exit();
    }
}

// Validar coincidencia de contraseñas
if ($_POST['password'] !== $_POST['confirm_password']) {
    header("Location: ../register.php?error=Las contraseñas no coinciden");
    exit();
}

// Validar formato de DNI (8 dígitos numéricos)
if (!preg_match('/^\d{8}$/', $_POST['dni'])) {
    header("Location: ../register.php?error=El DNI debe tener 8 dígitos numéricos");
    exit();
}

// Validar longitud mínima de contraseña
if (strlen($_POST['password']) < 6) {
    header("Location: ../register.php?error=La contraseña debe tener al menos 6 caracteres");
    exit();
}

// Sanitizar y preparar datos
$dni = mysqli_real_escape_string($conexion, trim($_POST['dni']));
$nombre = mysqli_real_escape_string($conexion, trim($_POST['nombre']));
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

// Verificar si el DNI ya existe (usando consulta preparada)
$check_query = "SELECT dni FROM empleados WHERE dni = ?";
$stmt = mysqli_prepare($conexion, $check_query);
mysqli_stmt_bind_param($stmt, "s", $dni);
mysqli_stmt_execute($stmt);
mysqli_stmt_store_result($stmt);

if (mysqli_stmt_num_rows($stmt) > 0) {
    mysqli_stmt_close($stmt);
    header("Location: ../register.php?error=El DNI ya está registrado");
    exit();
}
mysqli_stmt_close($stmt);

// Insertar nuevo usuario (usando consulta preparada)
$query = "INSERT INTO empleados (dni, nombre, password) VALUES (?, ?, ?)";
$stmt = mysqli_prepare($conexion, $query);
mysqli_stmt_bind_param($stmt, "sss", $dni, $nombre, $password);

if (mysqli_stmt_execute($stmt)) {
    // Registro exitoso - podrías iniciar sesión automáticamente si lo deseas
    $_SESSION['registro_exitoso'] = true;
    header("Location: ../index.php?registro=exitoso");
} else {
    error_log("Error al registrar usuario: " . mysqli_error($conexion));
    header("Location: ../register.php?error=Error al registrar. Por favor, intente nuevamente.");
}

mysqli_stmt_close($stmt);
mysqli_close($conexion);
exit();
?>