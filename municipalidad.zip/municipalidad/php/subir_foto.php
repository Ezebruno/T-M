<?php
session_start();
require_once "conexion.php"; // Asegúrate de tener tu conexión MySQL

if (!isset($_SESSION['id'])) {
    exit("Acceso denegado");
}

if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] == 0) {
    // Validaciones básicas (tipo y tamaño)
    $permitidos = ['image/jpeg', 'image/png', 'image/jpg'];
    if (in_array($_FILES['foto_perfil']['type'], $permitidos) && $_FILES['foto_perfil']['size'] <= 2 * 1024 * 1024) {
        $nombre_archivo = basename($_FILES["foto_perfil"]["name"]);
        $ruta_destino = "uploads/perfil_" . $_SESSION["id"] . "_" . time() . "_" . $nombre_archivo;

        if (!file_exists("uploads")) {
            mkdir("uploads", 0755, true);
        }

        if (move_uploaded_file($_FILES["foto_perfil"]["tmp_name"], $ruta_destino)) {
            // Guardar ruta en la base de datos
            $stmt = $conexion->prepare("UPDATE empleados SET foto_perfil = ? WHERE id = ?");
            $stmt->bind_param("si", $ruta_destino, $_SESSION['id']);
            $stmt->execute();
            $stmt->close();
        }
    }
}

$conexion->close();
header("Location: perfil.php");
exit;
