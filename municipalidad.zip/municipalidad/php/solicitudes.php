<?php
// Iniciar sesión y verificar autenticación
session_start();

// Redirigir si no está autenticado o no es empleado
if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'empleado') {
    header("Location: ../index.php");
    exit();
}

// Configuración y conexión a la base de datos
require_once "conexion.php";

// Constantes para configuración
define('UPLOAD_DIR', 'uploads/solicitudes/');
define('ALLOWED_EXTENSIONS', ['pdf', 'jpg', 'png', 'docx']);
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

// Procesamiento del formulario
$mensaje_enviado = false;
$errores = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validar y sanitizar mensaje
    $mensaje = trim(filter_input(INPUT_POST, 'mensaje', FILTER_SANITIZE_STRING));
    
    if (empty($mensaje)) {
        $errores[] = "El mensaje no puede estar vacío";
    }

    // Procesar archivo adjunto si existe
    $archivo = null;
    
    if (!empty($_FILES['archivo']['name'])) {
        $file = $_FILES['archivo'];
        
        // Validar tamaño del archivo
        if ($file['size'] > MAX_FILE_SIZE) {
            $errores[] = "El archivo excede el tamaño máximo permitido (5MB)";
        }
        
        // Validar extensión
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($extension, ALLOWED_EXTENSIONS)) {
            $errores[] = "Tipo de archivo no permitido. Formatos aceptados: " . implode(', ', ALLOWED_EXTENSIONS);
        }
        
        // Si no hay errores, mover el archivo
        if (empty($errores)) {
            if (!is_dir(UPLOAD_DIR)) {
                mkdir(UPLOAD_DIR, 0755, true);
            }
            
            $nombre_archivo = sprintf(
                "certificado_%d_%d.%s",
                $_SESSION['id'],
                time(),
                $extension
            );
            
            $archivo = UPLOAD_DIR . $nombre_archivo;
            
            if (!move_uploaded_file($file['tmp_name'], $archivo)) {
                $errores[] = "Error al subir el archivo";
            }
        }
    }
    
    // Si no hay errores, guardar en la base de datos
    if (empty($errores)) {
        $stmt = $conexion->prepare("
            INSERT INTO solicitudes 
            (empleado_id, mensaje, archivo, fecha_creacion) 
            VALUES (?, ?, ?, NOW())
        ");
        
        $stmt->bind_param("iss", $_SESSION['id'], $mensaje, $archivo);
        
        if ($stmt->execute()) {
            $mensaje_enviado = true;
        } else {
            $errores[] = "Error al guardar la solicitud en la base de datos";
        }
        
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enviar Solicitud</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <style>
        .form-container {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }
        
        textarea, input[type="file"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: inherit;
        }
        
        textarea {
            min-height: 150px;
            resize: vertical;
        }
        
        .btn {
            display: inline-block;
            padding: 0.85rem 2.5rem;
            background: #4a6fa5;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #3a5a8a;
        }
        
        .btn-secondary {
            background: #6c757d;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .file-info {
            font-size: 0.875rem;
            color: #666;
            margin-top: 0.5rem;
        }
        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: space-between;
        }

        .form-actions .btn {
            flex: 1;
            text-align: center;
        }

    </style>
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <h1>Enviar Solicitud</h1>
        </header>
        
        <main class="dashboard-main">
            <div class="form-container">
                <?php if ($mensaje_enviado): ?>
                    <div class="alert alert-success">
                        Solicitud enviada correctamente.
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errores)): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php foreach ($errores as $error): ?>
                                <li><?= htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="mensaje">Mensaje *</label>
                        <textarea 
                            name="mensaje" 
                            id="mensaje" 
                            required
                            placeholder="Escribe aquí los detalles de tu solicitud..."
                        ><?= isset($mensaje) ? htmlspecialchars($mensaje) : '' ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="archivo">Adjuntar archivo (opcional)</label>
                        <input type="file" name="archivo" id="archivo" accept=".pdf,.jpg,.png,.docx">
                        <p class="file-info">
                            Formatos aceptados: PDF, JPG, PNG, DOCX. Tamaño máximo: 5MB.
                        </p>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn">Enviar Solicitud</button>
                        <a href="dashboard.php" class="btn btn-secondary">Volver al Panel</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>

<?php
// Cerrar conexión a la base de datos
$conexion->close();
?>