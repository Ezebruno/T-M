<?php
session_start();
require_once 'conexion.php';

// Verificar que el usuario es administrador
if ($_SESSION['rol'] !== 'admin') {
    header('Location: acceso_denegado.php');
    exit;
}

// Verificar que se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['solicitud_id'], $_POST['accion'])) {
    $solicitud_id = intval($_POST['solicitud_id']);
    $accion = $_POST['accion'];
    $comentario = isset($_POST['comentario']) ? trim($_POST['comentario']) : '';
    
    // Validar acción
    if (!in_array($accion, ['aprobar', 'rechazar'])) {
        $_SESSION['error'] = 'Acción no válida';
        header('Location: dashboard.php');
        exit;
    }
    
    // Actualizar la solicitud
    $estado = $accion === 'aprobar' ? 'aprobada' : 'rechazada';
    $fecha_resolucion = date('Y-m-d H:i:s');
    
    $sql = "UPDATE solicitudes 
            SET estado = ?, 
                comentario_admin = ?, 
                fecha_resolucion = ?
            WHERE id = ?";
    
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, 'sssi', $estado, $comentario, $fecha_resolucion, $solicitud_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['exito'] = "Solicitud {$estado} correctamente";
    } else {
        $_SESSION['error'] = "Error al procesar la solicitud: " . mysqli_error($conexion);
    }
    
    mysqli_stmt_close($stmt);
}

header('Location: dashboard.php');
exit;
?>