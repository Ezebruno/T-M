<?php
session_start();

if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'admin') {
    header("HTTP/1.1 403 Forbidden");
    die("Acceso denegado. Redireccionando... <script>setTimeout(() => window.location.href='dashboard.php', 2000)</script>");
}

include("conexion.php");

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Aprobar certificado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        $_SESSION['mensaje'] = "Token CSRF inválido.";
        header("Location: aprobar_certificado.php");
        exit;
    }

    if (isset($_POST['aprobar'])) {
        $id = filter_var($_POST['aprobar'], FILTER_VALIDATE_INT);
        if ($id !== false) {
            $stmt = mysqli_prepare($conexion, "UPDATE certificados SET aprobado = 1, aprobado_por = ?, fecha_aprobacion = NOW(), motivo_rechazo = NULL WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "ii", $_SESSION['id'], $id);
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['mensaje'] = "Certificado aprobado correctamente.";
            } else {
                $_SESSION['mensaje'] = "Error al aprobar el certificado.";
            }
            mysqli_stmt_close($stmt);
        }
    }

    // Rechazar certificado con motivo
    if (isset($_POST['rechazar'])) {
        $id = filter_var($_POST['rechazar'], FILTER_VALIDATE_INT);
        $motivo = trim($_POST['motivo_rechazo'] ?? '');
        if ($id !== false && $motivo !== '') {
            $stmt = mysqli_prepare($conexion, "UPDATE certificados SET aprobado = 2, aprobado_por = ?, fecha_aprobacion = NOW(), motivo_rechazo = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "isi", $_SESSION['id'], $motivo, $id);
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['mensaje'] = "Certificado rechazado correctamente.";
            } else {
                $_SESSION['mensaje'] = "Error al rechazar el certificado.";
            }
            mysqli_stmt_close($stmt);
        } else {
            $_SESSION['mensaje'] = "Debe ingresar un motivo para el rechazo.";
        }
    }

    header("Location: aprobar_certificado.php");
    exit;
}

// Obtener certificados
$query = "SELECT c.id, e.nombre, c.archivo, c.aprobado, c.fecha_envio, c.motivo_rechazo 
          FROM certificados c 
          JOIN empleados e ON c.empleado_id = e.id 
          ORDER BY c.aprobado, c.fecha_envio DESC";
$result = mysqli_query($conexion, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Gestión de Certificados Médicos</title>
    <link rel="stylesheet" href="../css/admin.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <style>
        /* ... tu CSS previo ... */
        .btn-reject {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 8px;
        }
        .btn-reject:hover {
            background-color: #c82333;
        }
        /* Modal simple */
        .modal {
            display: none;
            position: fixed;
            z-index: 999;
            left: 0; top: 0; width: 100%; height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 400px;
            box-shadow: 0 0 10px rgba(0,0,0,0.25);
            position: relative;
        }
        .modal-content textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            resize: vertical;
            font-size: 1rem;
        }
        .modal-content button {
            margin-top: 12px;
            width: 100%;
            padding: 12px;
            font-weight: bold;
            border-radius: 8px;
            border: none;
            cursor: pointer;
        }
        .modal-content .btn-submit {
            background-color: #dc3545;
            color: white;
        }
        .modal-content .btn-cancel {
            background-color: #6c757d;
            color: white;
            margin-top: 8px;
        }
        .close-btn {
            position: absolute;
            top: 10px; right: 15px;
            font-size: 1.5rem;
            font-weight: bold;
            color: #aaa;
            cursor: pointer;
        }
        .close-btn:hover {
            color: black;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h1><i class="fas fa-file-medical"></i> Certificados Médicos</h1>

        <?php if (!empty($_SESSION['mensaje'])): ?>
            <div class="alert <?= strpos($_SESSION['mensaje'], 'error') !== false ? 'alert-danger' : 'alert-success' ?>">
                <?= htmlspecialchars($_SESSION['mensaje']) ?>
                <?php unset($_SESSION['mensaje']); ?>
            </div>
        <?php endif; ?>

        <div class="certificates-list">
            <table>
                <thead>
                    <tr>
                        <th>Empleado</th>
                        <th>Fecha</th>
                        <th>Archivo</th>
                        <th>Estado</th>
                        <th>Motivo Rechazo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['nombre']) ?></td>
                            <td><?= date('d/m/Y', strtotime($row['fecha_envio'])) ?></td>
                            <td>
                                <a href="../certificados/<?= htmlspecialchars(basename($row['archivo'])) ?>" target="_blank" class="btn-view">
                                    <i class="fas fa-eye"></i> Ver
                                </a>
                            </td>
                            <td>
                                <?php if ($row['aprobado'] == 1): ?>
                                    <span class="badge approved"><i class="fas fa-check-circle"></i> Aprobado</span>
                                <?php elseif ($row['aprobado'] == 2): ?>
                                    <span class="badge rejected" style="background-color:#f8d7da; color:#721c24;">
                                        <i class="fas fa-times-circle"></i> Rechazado
                                    </span>
                                <?php else: ?>
                                    <span class="badge pending"><i class="fas fa-clock"></i> Pendiente</span>
                                <?php endif; ?>
                            </td>
                            <td><?= nl2br(htmlspecialchars($row['motivo_rechazo'])) ?></td>
                            <td>
                                <?php if ($row['aprobado'] == 0): ?>
                                    <form method="post" action="aprobar_certificado.php" style="display:inline;">
                                        <input type="hidden" name="aprobar" value="<?= $row['id'] ?>">
                                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                        <button type="submit" class="btn-approve">
                                            <i class="fas fa-check"></i> Aprobar
                                        </button>
                                    </form>
                                    <button class="btn-reject" onclick="abrirModal(<?= $row['id'] ?>)">Rechazar</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="admin-actions">
            <a href="dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Volver al Panel</a>
        </div>
    </div>

    <!-- Modal para rechazo -->
    <div id="modalRechazo" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="cerrarModal()">&times;</span>
            <h2>Motivo de Rechazo</h2>
            <form method="post" action="aprobar_certificado.php" id="formRechazo">
                <textarea name="motivo_rechazo" placeholder="Ingrese el motivo del rechazo..." required></textarea>
                <input type="hidden" name="rechazar" id="rechazarId" value="">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <button type="submit" class="btn-submit">Enviar Rechazo</button>
                <button type="button" class="btn-cancel" onclick="cerrarModal()">Cancelar</button>
            </form>
        </div>
    </div>

    <script>
        function abrirModal(id) {
            document.getElementById('rechazarId').value = id;
            document.getElementById('modalRechazo').style.display = 'block';
        }
        function cerrarModal() {
            document.getElementById('modalRechazo').style.display = 'none';
            document.getElementById('formRechazo').reset();
        }
        // Cerrar modal si se hace click fuera del contenido
        window.onclick = function(event) {
            const modal = document.getElementById('modalRechazo');
            if (event.target == modal) {
                cerrarModal();
            }
        }
    </script>
</body>
</html>

<?php
mysqli_close($conexion);
?>
