<?php
session_start();
require_once "conexion.php";

// Redirigir si ya está logueado
if (isset($_SESSION['id'])) {
    header("Location: " . ($_SESSION['rol'] === 'admin' ? 'panel_admin.php' : 'panel_empleado.php'));
    exit();
}

$errorMsg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitizar entradas
    $usuario = trim($_POST['dni'] ?? '');
    $contrasena = $_POST['password'] ?? '';

    if (empty($usuario) || empty($contrasena)) {
        $errorMsg = "dni y password son requeridos";
    } else {
        // Consulta preparada
        $query = "SELECT id, dni, password as contrasena, rol, nombre FROM empleados WHERE dni = ? LIMIT 1";
        $stmt = mysqli_prepare($conexion, $query);
        mysqli_stmt_bind_param($stmt, "s", $usuario);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            // Verificar contraseña hasheada
            if (password_verify($contrasena, $row['contrasena'])) {
                // Regenerar ID de sesión para prevenir fixation
                session_regenerate_id(true);

                // Establecer datos de sesión
                $_SESSION = [
                    'id' => $row['id'],
                    'dni' => $row['dni'],
                    'nombre' => $row['nombre'],
                    'rol' => $row['rol'],
                    'ip' => $_SERVER['REMOTE_ADDR'],
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'],
                    'last_activity' => time()
                ];

                // Redirigir según rol
                header("Location: " . ($row['rol'] === 'admin' ? 'panel_admin.php' : 'panel_empleado.php'));
                exit();
            }
        }
        
        // Error genérico (no revelar si el usuario existe)
        $errorMsg = "Credenciales inválidas";
        sleep(2); // Retraso para prevenir fuerza bruta
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="css/auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .auth-container {
            max-width: 400px;
            margin: 5rem auto;
            padding: 2rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .auth-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .auth-header h1 {
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #555;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }
        .btn-login {
            width: 100%;
            padding: 0.75rem;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn-login:hover {
            background-color: #2980b9;
        }
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
            text-align: center;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .auth-footer {
            text-align: center;
            margin-top: 1.5rem;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-header">
            <h1><i class="fas fa-lock"></i> Iniciar Sesión</h1>
            <p>Sistema de Gestión de Empleados</p>
        </div>

        <?php if ($errorMsg): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($errorMsg) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="auth-form">
            <div class="form-group">
                <label for="dni"><i class="fas fa-user"></i> Dni:</label>
                <input type="text" id="dni" name="dni" class="form-control" required 
                       value="<?= htmlspecialchars($_POST['dni'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label for="password"><i class="fas fa-key"></i> password:</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>

            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt"></i> Ingresar
            </button>
        </form>

        <div class="auth-footer">
            <p>¿Problemas para ingresar? <a href="recuperar.php">Contacte al administrador</a></p>
        </div>
    </div>
</body>
</html>