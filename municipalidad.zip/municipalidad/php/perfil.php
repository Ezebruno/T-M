<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("HTTP/1.1 403 Forbidden");
    exit("Acceso no autorizado. <a href='index.php'>Iniciar sesión</a>");
}
require_once "conexion.php";

// Verificar si es búsqueda por DNI (solo para administradores)
$buscarPorDNI = isset($_GET['dni']) && $_SESSION['rol'] === 'admin';

if ($buscarPorDNI) {
    // Validar que el DNI tenga 8 dígitos
    if (!preg_match('/^[0-9]{8}$/', $_GET['dni'])) {
        header("Location: buscar_empleado.php?error=invalid_dni");
        exit();
    }
    
    // Buscar empleado por DNI
    $stmt = $conexion->prepare("SELECT * FROM empleados WHERE dni = ?");
    $stmt->bind_param("s", $_GET['dni']);
} else {
    // Buscar empleado por ID de sesión
    $stmt = $conexion->prepare("SELECT * FROM empleados WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['id']);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    if ($buscarPorDNI) {
        header("Location: buscar_empleado.php?error=employee_not_found");
    } else {
        header("HTTP/1.1 404 Not Found");
        exit("Perfil no encontrado");
    }
    exit();
}

$empleado = $result->fetch_assoc();
$stmt->close();

// Verificar si el usuario tiene permiso para ver este perfil
// (solo si no es admin viendo otro perfil o el propio usuario)
if ($_SESSION['id'] != $empleado['id'] && $_SESSION['rol'] != 'admin') {
    header("HTTP/1.1 403 Forbidden");
    exit("No tienes permiso para ver este perfil");
}

// Verificar si hay foto de perfil cargada
$tieneFotoPerfil = !empty($empleado['foto_perfil']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<title>Mi Perfil</title>
<link rel="stylesheet" href="../css/admin.css" />
<link
  rel="stylesheet"
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
/>
<style>
  .profile-container {
    max-width: 700px;
    margin: 2rem auto;
    padding: 2rem;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    font-family: "Segoe UI", sans-serif;
  }
  .profile-header {
    display: flex;
    align-items: center;
    margin-bottom: 2rem;
  }
  .profile-avatar {
    position: relative;
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: #f0f2f5;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    color: #4a6fa5;
    margin-right: 1.5rem;
    overflow: hidden;
    cursor: pointer;
  }
  .profile-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  .edit-icon {
      position: absolute;
      bottom: 4px;          /* Ajusta posición vertical */
      right: -57px;           /* Ajusta posición horizontal */
      color:rgb(0, 0, 0);       /* Color azul (puedes cambiarlo a #333 para gris oscuro o white para blanco) */
      cursor: pointer;
      font-size: 0.999rem;     /* Tamaño del ícono (ajustable) */
      z-index: 2;
      background: none;      /* Sin fondo */
      border: none;          /* Sin borde */
      padding: 0;            /* Sin padding */
      opacity: 0.9;          /* Ligera transparencia para integración visual */
      transition: opacity 0.2s;
  }

  .edit-icon:hover {
      opacity: 1;            /* Opacidad completa al pasar el mouse */
      color: #3b5980;        /* Color más oscuro al hover (opcional) */
  }
  .profile-info h2 {
    margin: 0;
    color: #333;
    font-size: 1.5rem;
  }
  .info-row {
    margin-bottom: 0.5rem;
  }
  .section-toggle {
    margin: 1.5rem 0;
    display: flex;
    gap: 1rem;
  }
  .toggle-button {
    padding: 0.5rem 1rem;
    background: #4a6fa5;
    color: #fff;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    flex: 1;
    transition: background-color 0.3s;
  }
  .toggle-button:hover {
    background: #3b5980;
  }
  .section-content {
    display: none;
    margin-top: 1rem;
    padding: 1rem;
    border-top: 1px solid #ccc;
    border-radius: 10px;
    background: #fafafa;
    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
  }
  .pair-row {
    display: flex;
    gap: 1rem;
    margin-bottom: 1.5rem;
  }
  .pair-item {
    flex: 1 1 50%;
    background: #f9f9fb;
    border: 1px solid #ddd;
    border-radius: 10px;
    padding: 1rem;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    transition: box-shadow 0.3s;
  }
  .pair-item:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }
  .pair-item img {
    max-width: 100px;
    margin-bottom: 0.5rem;
    border-radius: 6px;
    object-fit: contain;
    cursor: pointer;
  }
  label {
    font-weight: 600;
    margin-bottom: 0.3rem;
    display: block;
    width: 100%;
    text-align: left;
  }
  input[type="file"],
  input[type="text"] {
    width: 100%;
    padding: 0.4rem 0.6rem;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 0.9rem;
  }
  input[type="file"] {
    cursor: pointer;
  }
  button[type="submit"] {
    margin-top: 1rem;
    padding: 0.7rem 1.5rem;
    background: #4a6fa5;
    color: #fff;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1rem;
    transition: background-color 0.3s;
    align-self: flex-start;
  }
  button[type="submit"]:hover {
    background: #3b5980;
  }
  .back-button {
    display: inline-block;
    margin-top: 2rem;
    padding: 0.75rem 1.5rem;
    background: #6c757d;
    color: #fff;
    text-decoration: none;
    border-radius: 8px;
    transition: background-color 0.3s;
  }
  .back-button:hover {
    background: #5a6268;
  }
  @media (max-width: 480px) {
    .pair-row {
      flex-direction: column;
    }
    .pair-item {
      flex: 1 1 100%;
    }
  }
  
  /* Estilo para el modal */
  .modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.8);
    overflow: auto;
  }
  .modal-content {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
  }
  .modal-content img {
    max-width: 90%;
    max-height: 90%;
    object-fit: contain;
  }
  .close {
    position: absolute;
    top: 20px;
    right: 30px;
    color: #fff;
    font-size: 35px;
    font-weight: bold;
    cursor: pointer;
  }
</style>
<script>
  function toggleSection(id) {
    const secciones = ["ver-documentos", "editar-perfil"];
    secciones.forEach((sec) => {
      const el = document.getElementById(sec);
      el.style.display =
        sec === id ? (el.style.display === "block" ? "none" : "block") : "none";
    });
  }
  
  // Función para mostrar la imagen en modal
  function mostrarImagenModal(src) {
    const modal = document.getElementById('imagenModal');
    const modalImg = document.getElementById('imagenModalContent');
    modal.style.display = "block";
    modalImg.src = src;
  }
  
  // Cerrar el modal al hacer clic en la X
  function cerrarModal() {
    document.getElementById('imagenModal').style.display = "none";
  }
  
  // Cerrar el modal al hacer clic fuera de la imagen
  window.onclick = function(event) {
    const modal = document.getElementById('imagenModal');
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
</script>
</head>
<body>
  <!-- Modal para mostrar la imagen -->
  <div id="imagenModal" class="modal">
    <span class="close" onclick="cerrarModal()">&times;</span>
    <div class="modal-content">
      <img id="imagenModalContent" src="" alt="Imagen ampliada">
    </div>
  </div>

  <div class="profile-container">
    <div class="profile-header">
      <form id="form-foto" action="subir_foto.php" method="post" enctype="multipart/form-data" style="margin:0;">
        <div class="profile-avatar" onclick="<?= $tieneFotoPerfil ? "mostrarImagenModal('".htmlspecialchars($empleado['foto_perfil'])."')" : '' ?>">
          <?php if($tieneFotoPerfil): ?>
            <img src="<?= htmlspecialchars($empleado['foto_perfil']) ?>" alt="Foto de perfil">
          <?php else: ?>
            <i class="fas fa-user"></i>
          <?php endif; ?>
          <label for="foto_perfil" class="edit-icon" title="Cambiar foto de perfil">
            <i class="fas fa-pencil-alt"></i>
          </label>
          <input type="file" id="foto_perfil" name="foto_perfil" accept="image/*" style="display:none" onchange="document.getElementById('form-foto').submit();" />
        </div>
      </form>
      <div class="profile-info">
        <h2><?= htmlspecialchars($empleado["nombre"]) ?></h2>
        <p><?= ($empleado["activo"] ?? 1) ? "Activo" : "Inactivo" ?></p>
      </div>
    </div>
    <div class="info-row"><strong>DNI:</strong> <?= htmlspecialchars($empleado["dni"]) ?></div>
    <div class="info-row"><strong>Legajo:</strong> <?= htmlspecialchars($empleado["legajo"] ?? "No cargado") ?></div>

    <div class="section-toggle">
      <button class="toggle-button" onclick="toggleSection('ver-documentos')">Ver Documentación</button>
      <button class="toggle-button" onclick="toggleSection('editar-perfil')">Editar Perfil</button>
    </div>

    <div id="ver-documentos" class="section-content">
      <h3>Documentación Cargada</h3>
      <div class="pair-row">
        <div class="pair-item">
          <strong>DNI Frente:</strong><br />
          <?= !empty($empleado["dni_frente"]) ? "<img src='" . htmlspecialchars($empleado["dni_frente"]) . "' alt='DNI Frente' onclick=\"mostrarImagenModal('".htmlspecialchars($empleado["dni_frente"])."')\">" : "No cargado" ?>
        </div>
        <div class="pair-item">
          <strong>DNI Dorso:</strong><br />
          <?= !empty($empleado["dni_dorso"]) ? "<img src='" . htmlspecialchars($empleado["dni_dorso"]) . "' alt='DNI Dorso' onclick=\"mostrarImagenModal('".htmlspecialchars($empleado["dni_dorso"])."')\">" : "No cargado" ?>
        </div>
      </div>
      <div class="pair-row">
        <div class="pair-item">
          <strong>Licencia de Conducir Frente:</strong><br />
          <?= !empty($empleado["licencia_frente"]) ? "<img src='" . htmlspecialchars($empleado["licencia_frente"]) . "' alt='Licencia Frente' onclick=\"mostrarImagenModal('".htmlspecialchars($empleado["licencia_frente"])."')\">" : "No cargado" ?>
        </div>
        <div class="pair-item">
          <strong>Licencia de Conducir Dorso:</strong><br />
          <?= !empty($empleado["licencia_dorso"]) ? "<img src='" . htmlspecialchars($empleado["licencia_dorso"]) . "' alt='Licencia Dorso' onclick=\"mostrarImagenModal('".htmlspecialchars($empleado["licencia_dorso"])."')\">" : "No cargado" ?>
        </div>
      </div>
      <div class="pair-row">
        <div class="pair-item">
          <strong>Tarjeta IERIC Frente:</strong><br />
          <?= !empty($empleado["ieric_frente"]) ? "<img src='" . htmlspecialchars($empleado["ieric_frente"]) . "' alt='IERIC Frente' onclick=\"mostrarImagenModal('".htmlspecialchars($empleado["ieric_frente"])."')\">" : "No cargado" ?>
        </div>
        <div class="pair-item">
          <strong>Tarjeta IERIC Dorso:</strong><br />
          <?= !empty($empleado["ieric_dorso"]) ? "<img src='" . htmlspecialchars($empleado["ieric_dorso"]) . "' alt='IERIC Dorso' onclick=\"mostrarImagenModal('".htmlspecialchars($empleado["ieric_dorso"])."')\">" : "No cargado" ?>
        </div>
      </div>
      <div class="pair-row">
        <div class="pair-item">
          <strong>Declaración jurada:</strong><br />
          <?= !empty($empleado["declaracion_jurada"]) ? "<a href='" . htmlspecialchars($empleado["declaracion_jurada"]) . "' target='_blank'>Ver archivo</a>" : "No cargado" ?>
        </div>
        <div class="pair-item">
          <strong>CVU:</strong><br />
          <?= htmlspecialchars($empleado["cvu"] ?? "No cargado") ?>
        </div>
      </div>
    </div>

    <div id="editar-perfil" class="section-content">
      <h3>Editar Perfil</h3>
      <form action="actualizar_perfil.php" method="post" enctype="multipart/form-data">
        <div class="pair-row">
          <div class="pair-item">
            <label for="dni_frente">DNI Frente:</label>
            <input type="file" name="dni_frente" id="dni_frente" accept="image/*" />
          </div>
          <div class="pair-item">
            <label for="dni_dorso">DNI Dorso:</label>
            <input type="file" name="dni_dorso" id="dni_dorso" accept="image/*" />
          </div>
        </div>
        <div class="pair-row">
          <div class="pair-item">
            <label for="licencia_frente">Licencia de Conducir Frente:</label>
            <input type="file" name="licencia_frente" id="licencia_frente" accept="image/*" />
          </div>
          <div class="pair-item">
            <label for="licencia_dorso">Licencia de Conducir Dorso:</label>
            <input type="file" name="licencia_dorso" id="licencia_dorso" accept="image/*" />
          </div>
        </div>
        <div class="pair-row">
          <div class="pair-item">
            <label for="ieric_frente">Tarjeta IERIC Frente:</label>
            <input type="file" name="ieric_frente" id="ieric_frente" accept="image/*" />
          </div>
          <div class="pair-item">
            <label for="ieric_dorso">Tarjeta IERIC Dorso:</label>
            <input type="file" name="ieric_dorso" id="ieric_dorso" accept="image/*" />
          </div>
        </div>
        <div class="pair-row">
          <div class="pair-item">
            <label for="declaracion_jurada">Declaración jurada:</label>
            <input type="file" name="declaracion_jurada" id="declaracion_jurada" accept=".pdf,image/*" />
          </div>
        </div>
        <div class="pair-row">
          <div class="pair-item">
            <label for="legajo">Número de legajo:</label>
            <input type="text" name="legajo" id="legajo" value="<?= htmlspecialchars($empleado["legajo"] ?? "") ?>" />
          </div>
          <div class="pair-item">
            <label for="cvu">CVU:</label>
            <input type="text" name="cvu" id="cvu" value="<?= htmlspecialchars($empleado["cvu"] ?? "") ?>" />
          </div>
        </div>
        <button type="submit">Guardar Cambios</button>
      </form>
    </div>

    <a href="dashboard.php" class="back-button">Volver al Panel</a>
  </div>
</body>
</html>
<?php $conexion->close(); ?>