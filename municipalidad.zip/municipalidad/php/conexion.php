<?php
$conexion = mysqli_connect(
    'localhost',      // servidor
    'root',           // usuario
    '1234',           // contraseña (vacía en XAMPP por defecto)
    'municipalidad',  // base de datos
    3307              // puerto (¡agregado!)
);

if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}
?>