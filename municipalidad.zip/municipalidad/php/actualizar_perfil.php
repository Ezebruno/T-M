<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("HTTP/1.1 403 Forbidden");
    exit("Acceso no autorizado");
}

require_once "conexion.php";

$id = $_SESSION['id'];
$uploads_dir = 'uploads/';

// Crear carpeta si no existe
if (!is_dir($uploads_dir)) {
    mkdir($uploads_dir, 0777, true);
}

// Función para subir archivo
function subirArchivo($campo, $uploads_dir) {
    if (isset($_FILES[$campo]) && $_FILES[$campo]['error'] === UPLOAD_ERR_OK) {
        $tmp_name = $_FILES[$campo]["tmp_name"];
        $nombre = basename($_FILES[$campo]["name"]);
        $nombre_unico = uniqid() . "_" . $nombre;
        $destino = $uploads_dir . $nombre_unico;
        if (move_uploaded_file($tmp_name, $destino)) {
            return $destino;
        }
    }
    return null;
}

// Subir archivos y obtener rutas
$dni_frente = subirArchivo('dni_frente', $uploads_dir);
$dni_dorso = subirArchivo('dni_dorso', $uploads_dir);
$licencia_frente = subirArchivo('licencia_frente', $uploads_dir);
$licencia_dorso = subirArchivo('licencia_dorso', $uploads_dir);
$ieric_frente = subirArchivo('ieric_frente', $uploads_dir);
$ieric_dorso = subirArchivo('ieric_dorso', $uploads_dir);
$declaracion_jurada = subirArchivo('declaracion_jurada', $uploads_dir);

// Datos de texto
$legajo = $_POST['legajo'] ?? '';
$cvu = $_POST['cvu'] ?? '';

// Armar consulta con solo los campos que se subieron
$campos = [];
$parametros = [];
$tipos = '';

if ($dni_frente) {
    $campos[] = "dni_frente = ?";
    $parametros[] = $dni_frente;
    $tipos .= 's';
}
if ($dni_dorso) {
    $campos[] = "dni_dorso = ?";
    $parametros[] = $dni_dorso;
    $tipos .= 's';
}
if ($licencia_frente) {
    $campos[] = "licencia_frente = ?";
    $parametros[] = $licencia_frente;
    $tipos .= 's';
}
if ($licencia_dorso) {
    $campos[] = "licencia_dorso = ?";
    $parametros[] = $licencia_dorso;
    $tipos .= 's';
}
if ($ieric_frente) {
    $campos[] = "ieric_frente = ?";
    $parametros[] = $ieric_frente;
    $tipos .= 's';
}
if ($ieric_dorso) {
    $campos[] = "ieric_dorso = ?";
    $parametros[] = $ieric_dorso;
    $tipos .= 's';
}
if ($declaracion_jurada) {
    $campos[] = "declaracion_jurada = ?";
    $parametros[] = $declaracion_jurada;
    $tipos .= 's';
}

// Datos obligatorios
$campos[] = "legajo = ?";
$parametros[] = $legajo;
$tipos .= 's';

$campos[] = "cvu = ?";
$parametros[] = $cvu;
$tipos .= 's';

// Agregar ID para el WHERE
$parametros[] = $id;
$tipos .= 'i';

$sql = "UPDATE empleados SET " . implode(", ", $campos) . " WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param($tipos, ...$parametros);

if ($stmt->execute()) {
    echo "Perfil actualizado correctamente. <a href='perfil.php'>Volver al perfil</a>";
} else {
    echo "Error al actualizar: " . $stmt->error;
}

$stmt->close();
$conexion->close();
?>
