<?php
session_start();

if (!isset($_SESSION['id']) || !isset($_SESSION['rol']) || $_SESSION['rol'] != 'admin') {
    header("Location: ../index.php?error=access_denied");
    exit();
}

include("conexion.php");

// Obtener información del usuario admin
$query = "SELECT nombre FROM empleados WHERE id = ?";
$stmt = mysqli_prepare($conexion, $query);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Manejar mensajes de error
$error_message = '';
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'invalid_dni':
            $error_message = "El DNI ingresado no es válido. Debe contener 8 dígitos.";
            break;
        case 'employee_not_found':
            $error_message = "No se encontró ningún empleado con ese DNI.";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscar Empleado</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background: url('../img/fondo.png') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 2rem;
        }
        .upload-container {
            max-width: 700px;
            margin: 0 auto;
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 1.5rem;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #333;
        }
        input[type="text"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
        }
        .btn {
            background-color: #4a6fa5;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            font-size: 1rem;
            margin-top: 1rem;
            transition: background-color 0.3s;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #3a5a8a;
        }
        .alert {
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1.5rem;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .btn-back {
            background-color: #6c757d;
            display: inline-block;
            text-align: center;
            padding: 10px 22px;
            font-size: 1.2rem;
            border-radius: 8px;
            color: white;
            margin-top: 2rem;
        }
        .btn-back:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <div class="upload-container">
        <h1><i class="fas fa-user-search"></i> Buscar Empleado</h1>

        <p><strong>Administrador:</strong> <?= htmlspecialchars($user['nombre'] ?? 'Admin') ?></p>

        <?php if (!empty($error_message)): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?= $error_message ?>
            </div>
        <?php endif; ?>

        <form action="perfil.php" method="get">
            <div class="form-group">
                <label for="dni">Ingrese DNI del empleado:</label>
                <input type="text" id="dni" name="dni" required 
                       pattern="[0-9]{8}" title="Ingrese un DNI válido (8 dígitos)"
                       placeholder="Ejemplo: 12345678">
            </div>
            <button type="submit" class="btn">
                <i class="fas fa-search"></i> Buscar Empleado
            </button>
        </form>

        <div class="btn-container">
            <a href="dashboard.php" class="btn-back">
                <i class="fas fa-home"></i> Volver al Menú
            </a>
        </div>
    </div>
</body>
</html>

<?php
mysqli_close($conexion);
?>
