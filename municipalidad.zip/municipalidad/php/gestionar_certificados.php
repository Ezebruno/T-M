<?php
session_start();

if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'admin') {
    header("HTTP/1.1 403 Forbidden");
    die("Acceso denegado. Redireccionando... <script>setTimeout(() => window.location.href='dashboard.php', 2000)</script>");
}

include("conexion.php");

// Token CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Aprobación
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aprobar'])) {
    $id = filter_var($_POST['aprobar'], FILTER_VALIDATE_INT);
    $token = $_POST['csrf_token'] ?? '';
    
    if ($id !== false && hash_equals($_SESSION['csrf_token'], $token)) {
        $stmt = mysqli_prepare($conexion, "UPDATE certificados SET aprobado = 1, aprobado_por = ?, fecha_aprobacion = NOW(), rechazado_por = NULL, fecha_rechazo = NULL, motivo_rechazo = NULL WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "ii", $_SESSION['id'], $id);
        mysqli_stmt_execute($stmt);
        $_SESSION['mensaje'] = "✅ Certificado aprobado correctamente.";
        header("Location: gestionar_certificados.php");
        exit;
    }
}

// Rechazo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rechazar'])) {
    $id = filter_var($_POST['rechazar'], FILTER_VALIDATE_INT);
    $motivo = trim($_POST['motivo'] ?? '');
    $token = $_POST['csrf_token'] ?? '';

    if ($id !== false && hash_equals($_SESSION['csrf_token'], $token) && $motivo !== '') {
        $stmt = mysqli_prepare($conexion, "UPDATE certificados SET aprobado = 0, rechazado_por = ?, fecha_rechazo = NOW(), motivo_rechazo = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "isi", $_SESSION['id'], $motivo, $id);
        mysqli_stmt_execute($stmt);
        $_SESSION['mensaje'] = "❌ Certificado rechazado correctamente.";
        header("Location: gestionar_certificados.php");
        exit;
    } else {
        $_SESSION['mensaje'] = "⚠️ Debe ingresar un motivo válido.";
        header("Location: gestionar_certificados.php");
        exit;
    }
}

// Obtener certificados
$query = "SELECT c.id, e.nombre, c.archivo, c.aprobado, c.fecha_envio, c.motivo_rechazo 
          FROM certificados c 
          JOIN empleados e ON c.empleado_id = e.id 
          ORDER BY c.aprobado, c.fecha_envio DESC";
$result = mysqli_query($conexion, $query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Certificados</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background: url('../img/fondo.png') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 2rem;
        }
        .upload-container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 1.5rem;
        }
        .alert {
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .card {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            background: #fff;
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px;
        }
        .card-header h3 {
            margin: 0;
        }
        .card-info {
            margin-top: 0.75rem;
            font-size: 0.9rem;
            color: #555;
        }
        .card-actions {
            margin-top: 1.5rem;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .btn {
            padding: 0.6rem 1.2rem;
            border-radius: 4px;
            font-size: 0.9rem;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            border: none;
        }
        .btn-approve {
            background-color: #28a745;
            color: white;
        }
        .btn-approve:hover {
            background-color: #218838;
        }
        .btn-reject {
            background-color: #dc3545;
            color: white;
        }
        .btn-reject:hover {
            background-color: #c82333;
        }
        .btn-view {
            background-color: #007bff;
            color: white;
        }
        .btn-view:hover {
            background-color: #0056b3;
        }
        .badge {
            padding: 0.3rem 0.6rem;
            font-size: 0.8rem;
            font-weight: 600;
            border-radius: 12px;
        }
        .badge-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        .badge-approved {
            background-color: #d4edda;
            color: #155724;
        }
        .badge-rejected {
            background-color: #f8d7da;
            color: #721c24;
        }
        .motivo-rechazo {
            margin-top: 0.5rem;
            color: #721c24;
            font-style: italic;
        }
        .motivo-form {
            margin-top: 0.5rem;
        }
        .btn-container {
            text-align: center;
            margin-top: 2rem;
        }
        .btn-back {
            background-color: #6c757d;
            font-size: 1.2rem;
            padding: 10px 22px;
            min-width: 200px;
        }
        .btn-back:hover {
            background-color: #5a6268;
        }

        .alert-info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

    </style>
</head>
<body>
    <div class="upload-container">
        <h1><i class="fas fa-file-medical"></i> Gestión de Certificados Médicos</h1>

        <?php if (!empty($_SESSION['mensaje'])): ?>
            <div class="alert <?= strpos($_SESSION['mensaje'], '❌') !== false || strpos($_SESSION['mensaje'], '⚠️') !== false ? 'alert-danger' : 'alert-success' ?>">
                <?= htmlspecialchars($_SESSION['mensaje']) ?>
                <?php unset($_SESSION['mensaje']); ?>
            </div>
        <?php endif; ?>

        <?php if (mysqli_num_rows($result) === 0): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> No hay certificados enviados.
            </div>
        <?php else: ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="card">
                    <div class="card-header">
                        <h3><?= htmlspecialchars($row['nombre']) ?></h3>
                        <?php if ($row['aprobado']): ?>
                            <span class="badge badge-approved">Aprobado</span>
                        <?php elseif (!empty($row['motivo_rechazo'])): ?>
                            <span class="badge badge-rejected">Rechazado</span>
                        <?php else: ?>
                            <span class="badge badge-pending">Pendiente</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-info">
                        <p><strong>Fecha:</strong> <?= date('d/m/Y', strtotime($row['fecha_envio'])) ?></p>
                        <a href="../certificados/<?= htmlspecialchars(basename($row['archivo'])) ?>" class="btn btn-view" target="_blank"><i class="fas fa-eye"></i> Ver certificado</a>
                    </div>

                    <?php if (!empty($row['motivo_rechazo'])): ?>
                        <div class="motivo-rechazo"><strong>Motivo:</strong> <?= htmlspecialchars($row['motivo_rechazo']) ?></div>
                    <?php endif; ?>

                    <?php if (!$row['aprobado'] && empty($row['motivo_rechazo'])): ?>
                        <div class="card-actions">
                            <form method="post" style="display:inline;" onsubmit="return confirm('¿Aprobar este certificado?');">
                                <input type="hidden" name="aprobar" value="<?= $row['id'] ?>">
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                <button type="submit" class="btn btn-approve"><i class="fas fa-check-circle"></i> Aprobar</button>
                            </form>
                            <form method="post" style="display:inline;" onsubmit="return confirm('¿Rechazar este certificado?');">
                                <input type="hidden" name="rechazar" value="<?= $row['id'] ?>">
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                <input type="text" name="motivo" placeholder="Motivo del rechazo" required class="motivo-form">
                                <button type="submit" class="btn btn-reject"><i class="fas fa-times-circle"></i> Rechazar</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>

        <div class="btn-container">
            <a href="dashboard.php" class="btn btn-back"><i class="fas fa-home"></i> Volver al Menú</a>
        </div>
    </div>
</body>
</html>
<?php mysqli_close($conexion); ?>
