<?php
session_start();

// Verificación de sesión más segura
if (!isset($_SESSION['id']) || !isset($_SESSION['rol']) || !isset($_SESSION['last_activity'])) {
    header("Location: ../index.php?error=session_expired");
    exit();
}

// Verificar tiempo de inactividad (30 minutos)
if (time() - $_SESSION['last_activity'] > 1800) {
    session_unset();
    session_destroy();
    header("Location: ../index.php?error=session_timeout");
    exit();
}

// Actualizar tiempo de última actividad
$_SESSION['last_activity'] = time();

// Verificar integridad de la sesión
if ($_SESSION['ip_address'] !== $_SERVER['REMOTE_ADDR'] || 
    $_SESSION['user_agent'] !== $_SERVER['HTTP_USER_AGENT']) {
    session_unset();
    session_destroy();
    header("Location: ../index.php?error=session_hijacking");
    exit();
}

include("conexion.php");

// Obtener información del usuario
$query = "SELECT nombre FROM empleados WHERE id = ?";
$stmt = mysqli_prepare($conexion, $query);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Cargar el panel correspondiente según rol
if ($_SESSION['rol'] === 'admin') {
    include("panel_admin.php");
} else {
    include("panel_empleado.php");
}

mysqli_close($conexion);
?>