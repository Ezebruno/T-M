<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Panel de Control - <?= htmlspecialchars($user['nombre'] ?? 'Administrador') ?></title>
    <link rel="stylesheet" href="../css/dashboard.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
</head>
<body>
    <header class="dashboard-header">
        <h1>Bienvenido, <?= htmlspecialchars($user['nombre'] ?? 'Administrador') ?></h1>
        <div class="user-role">Rol: <?= htmlspecialchars($_SESSION['rol']) ?></div>
    </header>

    <nav class="dashboard-nav">
        <h2>Administración</h2>
        <ul>
            <li><a href="subir_recibo.php"><i class="fas fa-upload"></i> Subir Recibos de Sueldo</a></li>
            <li><a href="gestionar_certificados.php"><i class="fas fa-certificate"></i> Gestionar Certificados Médicos</a></li>
            <li><a href="gestionar_indumentaria.php"><i class="fas fa-tshirt"></i> Gestionar Indumentaria</a></li>
            <li><a href="agregar_empleado.php"><i class="fas fa-users-cog"></i> Agregar Empleado</a></li>
            <li><a href="eliminar_empleado.php"><i class="fas fa-users-cog"></i> Dar de Baja Empleado</a></li>
            <li><a href="buscar_empleado.php"><i class="fas fa-users-cog"></i> Ver Perfil Empleado</a></li>
        </ul>
    </nav>
    
<main class="dashboard-main">
    <section id="solicitudes" class="dashboard-section">
        <h2><i class="fas fa-envelope"></i> Solicitudes de Empleados</h2>

        <?php   
        $sql_solicitudes = "
            SELECT s.id, s.mensaje, s.archivo, s.fecha_creacion, s.estado, 
                   s.comentario_admin, s.fecha_resolucion, e.nombre
            FROM solicitudes s
            INNER JOIN empleados e ON s.empleado_id = e.id
            ORDER BY s.fecha_creacion DESC
        ";
        $result_solicitudes = mysqli_query($conexion, $sql_solicitudes);
        ?>

        <?php if (mysqli_num_rows($result_solicitudes) > 0): ?>
            <table class="dashboard-table solicitudes-table">
                <thead>
                    <tr>
                        <th>Empleado</th>
                        <th>Mensaje</th>
                        <th>Archivo</th>
                        <th>Fecha</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result_solicitudes)): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['nombre']) ?></td>
                            <td><?= nl2br(htmlspecialchars($row['mensaje'])) ?></td>
                            <td>
                                <?php if (!empty($row['archivo'])): ?>
                                    <a href="<?= htmlspecialchars($row['archivo']) ?>" target="_blank">Ver archivo</a>
                                <?php else: ?>
                                    Sin archivo
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($row['fecha_creacion']) ?></td>
                            <td>
                                <span class="estado-badge estado-<?= htmlspecialchars($row['estado']) ?>">
                                    <?= htmlspecialchars(ucfirst($row['estado'])) ?>
                                </span>
                                <?php if ($row['estado'] != 'pendiente' && !empty($row['comentario_admin'])): ?>
                                    <div class="comentario-admin">
                                        <strong>Comentario:</strong> <?= nl2br(htmlspecialchars($row['comentario_admin'])) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($row['estado'] == 'pendiente'): ?>
                                    <div class="acciones-solicitud">
                                        <form method="post" action="procesar_solicitud.php" class="form-accion">
                                            <input type="hidden" name="solicitud_id" value="<?= $row['id'] ?>">
                                            <input type="hidden" name="accion" value="aprobar">
                                            <button type="submit" class="btn-aprobar"><i class="fas fa-check"></i> Aprobar</button>
                                        </form>
                                        <form method="post" action="procesar_solicitud.php" class="form-accion">
                                            <input type="hidden" name="solicitud_id" value="<?= $row['id'] ?>">
                                            <input type="hidden" name="accion" value="rechazar">
                                            <div class="comentario-container">
                                                <textarea name="comentario" placeholder="Comentario (opcional)" class="comentario-textarea"></textarea>
                                            </div>
                                            <button type="submit" class="btn-rechazar"><i class="fas fa-times"></i> Rechazar</button>
                                        </form>
                                    </div>
                                <?php else: ?>
                                    <span class="resuelto">Resuelto el <?= htmlspecialchars($row['fecha_resolucion']) ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No hay solicitudes aún.</p>
        <?php endif; ?>
    </section>
</main>

    <div class="dashboard-footer">
        <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
    </div>
</body>
</html>