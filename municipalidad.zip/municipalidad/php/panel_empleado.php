    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Panel de Control - Empleado - <?= htmlspecialchars($user['nombre'] ?? 'Empleado') ?></title>
        <link rel="stylesheet" href="../css/dashboard.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    </head>
    <body>
        <header class="dashboard-header">
            <h1>Bienvenido, <?= htmlspecialchars($user['nombre'] ?? 'Empleado') ?></h1>
            <div class="user-role">Rol: <?= htmlspecialchars($_SESSION['rol']) ?></div>
        </header>

        <nav class="dashboard-nav">
            <h2>Mis Herramientas</h2>
            <ul>
                <li><a href="ver_recibos.php"><i class="fas fa-file-invoice"></i> Mis Recibos</a></li>
                <li><a href="enviar_certificado.php"><i class="fas fa-paper-plane"></i> Enviar Certificado Médico</a></li>
                <li><a href="pedir_indumentaria.php"><i class="fas fa-shopping-bag"></i> Pedir Indumentaria</a></li>
                <li><a href="solicitudes.php"><i class="fas fa-envelope"></i> Enviar Solicitud</a></li>
                <li><a href="ver_solicitudes.php"><i class="fas fa-envelope"></i> Mis Solicitudes</a></li>
                <li><a href="perfil.php"><i class="fas fa-user-cog"></i> Mi Perfil</a></li>
            </ul>
        </nav>
        
        <div class="dashboard-footer">
            <a href="logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
        </div>
    </body>
    </html>