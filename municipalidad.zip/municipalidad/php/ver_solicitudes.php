<?php
// Iniciar sesión y verificar autenticación
session_start();

// Redirigir si no está autenticado o no es empleado
if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'empleado') {
    header("Location: ../index.php");
    exit();
}

// Configuración y conexión a la base de datos
require_once "conexion.php";

// Obtener las solicitudes del empleado
$solicitudes = [];
$stmt = $conexion->prepare("
    SELECT id, mensaje, archivo, fecha_creacion, estado, comentario_admin, fecha_resolucion
    FROM solicitudes
    WHERE empleado_id = ?
    ORDER BY fecha_creacion DESC
");
$stmt->bind_param("i", $_SESSION['id']);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado) {
    $solicitudes = $resultado->fetch_all(MYSQLI_ASSOC);
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Solicitudes</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .solicitudes-container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .solicitud-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            position: relative;
        }
        
        .solicitud-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #eee;
        }
        
        .solicitud-fecha {
            color: #666;
            font-size: 0.9rem;
        }
        
        .solicitud-estado {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .estado-pendiente {
            background-color: #FFF3CD;
            color: #856404;
        }
        
        .estado-aprobada {
            background-color: #D4EDDA;
            color: #155724;
        }
        
        .estado-rechazada {
            background-color: #F8D7DA;
            color: #721C24;
        }
        
        .solicitud-mensaje {
            margin-bottom: 1rem;
            white-space: pre-line;
        }
        
        .solicitud-archivo {
            margin-bottom: 1rem;
        }
        
        .solicitud-archivo a {
            color: #4a6fa5;
            text-decoration: none;
        }
        
        .solicitud-archivo a:hover {
            text-decoration: underline;
        }
        
        .solicitud-comentario {
            margin-top: 1rem;
            padding: 1rem;
            background-color: #f8f9fa;
            border-radius: 4px;
            border-left: 4px solid #6c757d;
        }
        
        .solicitud-comentario h4 {
            margin-top: 0;
            margin-bottom: 0.5rem;
            color: #495057;
        }
        
        .no-solicitudes {
            text-align: center;
            padding: 2rem;
            color: #666;
        }
        
        .btn-volver-panel {
            display: inline-block;
            margin-bottom: 1.5rem;
            padding: 0.6rem 1.2rem;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-weight: 600;
            transition: background 0.3s;
        }

        .btn-volver-panel:hover {
            background: #5a6268;
        }

    </style>
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <h1>Mis Solicitudes</h1>
        </header>
        
        <main class="dashboard-main">
            <div class="solicitudes-container">
                
                <?php if (empty($solicitudes)): ?>
                    <div class="no-solicitudes">
                        <p>No has enviado ninguna solicitud aún.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($solicitudes as $solicitud): ?>
                        <div class="solicitud-card">
                            <div class="solicitud-header">
                                <span class="solicitud-fecha">
                                    Enviada el <?= date('d/m/Y H:i', strtotime($solicitud['fecha_creacion'])) ?>
                                </span>
                                <span class="solicitud-estado estado-<?= $solicitud['estado'] ?>">
                                    <?= ucfirst($solicitud['estado']) ?>
                                </span>
                            </div>
                            
                            <div class="solicitud-mensaje">
                                <?= nl2br(htmlspecialchars($solicitud['mensaje'])) ?>
                            </div>
                            
                            <?php if (!empty($solicitud['archivo'])): ?>
                                <div class="solicitud-archivo">
                                    <i class="fas fa-paperclip"></i> 
                                    <a href="<?= htmlspecialchars($solicitud['archivo']) ?>" target="_blank">
                                        Ver archivo adjunto
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($solicitud['estado'] !== 'pendiente' && !empty($solicitud['comentario_admin'])): ?>
                                <div class="solicitud-comentario">
                                    <h4>
                                        <i class="fas fa-comment"></i> 
                                        Comentario del administrador
                                        <?php if (!empty($solicitud['fecha_resolucion'])): ?>
                                            <small>(<?= date('d/m/Y H:i', strtotime($solicitud['fecha_resolucion'])) ?>)</small>
                                        <?php endif; ?>
                                    </h4>
                                    <p><?= nl2br(htmlspecialchars($solicitud['comentario_admin'])) ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <a href="dashboard.php" class="btn-volver-panel">Volver al Panel</a>

        </main>
    </div>
</body>
</html>

<?php
// Cerrar conexión a la base de datos
$conexion->close();
?>