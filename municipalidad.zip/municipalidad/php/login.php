<?php
session_start();
include("conexion.php");

// Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../index.php?error=method_not_allowed");
    exit();
}

// Validar campos obligatorios
if (empty($_POST['dni']) || empty($_POST['password'])) {
    header("Location: ../index.php?error=campos_requeridos");
    exit();
}

// Validar formato de DNI
if (!preg_match('/^\d{8}$/', $_POST['dni'])) {
    header("Location: ../index.php?error=formato_dni_invalido");
    exit();
}

// Sanitizar entrada
$dni = mysqli_real_escape_string($conexion, trim($_POST['dni']));

// Consulta preparada para mayor seguridad
$query = "SELECT id, dni, nombre, password, rol FROM empleados WHERE dni = ? LIMIT 1";
$stmt = mysqli_prepare($conexion, $query);
mysqli_stmt_bind_param($stmt, "s", $dni);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result || mysqli_num_rows($result) === 0) {
    header("Location: ../index.php?error=credenciales_invalidas");
    mysqli_stmt_close($stmt);
    exit();
}

$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Verificar contraseña
if (password_verify($_POST['password'], $user['password'])) {
    session_regenerate_id(true);
    
    $_SESSION = [
        'id' => $user['id'],
        'dni' => $user['dni'],
        'nombre' => $user['nombre'],
        'rol' => $user['rol'],
        'last_activity' => time(),
        'ip_address' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT']
    ];

    // Recordarme con cookies
    if (isset($_POST['recordarme'])) {
        setcookie('dni', $user['dni'], time() + (86400 * 30), "/");
        setcookie('password', $_POST['password'], time() + (86400 * 30), "/");
    } else {
        setcookie('dni', '', time() - 3600, "/");
        setcookie('password', '', time() - 3600, "/");
    }

    header("Location: dashboard.php");
    exit();
} else {
    header("Location: ../index.php?error=credenciales_invalidas");
    exit();
}

mysqli_close($conexion);
?>
