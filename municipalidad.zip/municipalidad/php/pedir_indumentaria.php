<?php
session_start();

// Verificación robusta de sesión
if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'empleado') {
    header("HTTP/1.1 403 Forbidden");
    exit('<div class="error">Acceso no autorizado. Redireccionando... 
          <script>setTimeout(()=>window.location.href="index.php", 2000)</script></div>');
}

require_once "conexion.php";

// Procesar formulario
$requestSuccess = false;
$errorMsg = '';
$pedidoId = null;
$estadoPedido = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_SESSION['id'];
    $nombre = trim($_POST['nombre']);
    $remera_talla = trim($_POST['remera_talla']);
    $pantalon_talla = trim($_POST['pantalon_talla']);
    $zapatos_talla = trim($_POST['zapatos_talla']);
    $comentarios = trim($_POST['comentarios']);
    $fecha_entrega = $_POST['fecha_entrega'];

    if (empty($nombre) || empty($remera_talla) || empty($pantalon_talla) || empty($zapatos_talla)) {
        $errorMsg = "Por favor complete todos los campos obligatorios.";
    } else {
        $mensaje = "Pedido de indumentaria - Nombre: $nombre\n";
        $mensaje .= "Talla Remera: $remera_talla\n";
        $mensaje .= "Talla Pantalón: $pantalon_talla\n";
        $mensaje .= "Talla Zapatos: $zapatos_talla\n";
        $mensaje .= "Comentarios: $comentarios\n";
        $mensaje .= "Fecha de Entrega Deseada: $fecha_entrega";

        $stmt = $conexion->prepare("INSERT INTO pedidos_indumentaria 
                                   (empleado_id, mensaje, fecha_pedido, estado) 
                                   VALUES (?, ?, NOW(), 'pendiente')");
        $stmt->bind_param("is", $id, $mensaje);

        if ($stmt->execute()) {
            $requestSuccess = true;
            $pedidoId = $stmt->insert_id;
        } else {
            $errorMsg = "Error al enviar el pedido. Por favor intente nuevamente.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pedido de Indumentaria</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <style>
        /* Mismos estilos del primer archivo */
        .form-container {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }

        input[type="text"], input[type="date"], textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: inherit;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        .btn {
            display: inline-block;
            padding: 0.85rem 2.5rem;
            background: #4a6fa5;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }

        .btn:hover {
            background: #3a5a8a;
        }

        .btn-secondary {
            background: #6c757d;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: space-between;
        }

        .form-actions .btn {
            flex: 1;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <h1>Pedido de Indumentaria</h1>
        </header>

        <main class="dashboard-main">
            <div class="form-container">
                <?php if ($requestSuccess): ?>
                    <div class="alert alert-success">
                        Pedido enviado correctamente. Estado actual: <strong>pendiente</strong>
                    </div>
                <?php elseif (!empty($errorMsg)): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($errorMsg) ?></div>
                <?php endif; ?>

                <form method="post">
                    <div class="form-group">
                        <label for="nombre">Nombre *</label>
                        <input type="text" name="nombre" id="nombre" required 
                               value="<?= isset($nombre) ? htmlspecialchars($nombre) : '' ?>">
                    </div>

                    <div class="form-group">
                        <label for="remera_talla">Talla de Remera *</label>
                        <input type="text" name="remera_talla" id="remera_talla" required 
                               value="<?= isset($remera_talla) ? htmlspecialchars($remera_talla) : '' ?>">
                    </div>

                    <div class="form-group">
                        <label for="pantalon_talla">Talla de Pantalón *</label>
                        <input type="text" name="pantalon_talla" id="pantalon_talla" required 
                               value="<?= isset($pantalon_talla) ? htmlspecialchars($pantalon_talla) : '' ?>">
                    </div>

                    <div class="form-group">
                        <label for="zapatos_talla">Talla de Zapatos *</label>
                        <input type="text" name="zapatos_talla" id="zapatos_talla" required 
                               value="<?= isset($zapatos_talla) ? htmlspecialchars($zapatos_talla) : '' ?>">
                    </div>

                    <div class="form-group">
                        <label for="fecha_entrega">Fecha Deseada de Entrega</label>
                        <input type="date" name="fecha_entrega" id="fecha_entrega"
                               value="<?= isset($fecha_entrega) ? htmlspecialchars($fecha_entrega) : '' ?>">
                    </div>

                    <div class="form-group">
                        <label for="comentarios">Comentarios Adicionales</label>
                        <textarea name="comentarios" id="comentarios"
                                  placeholder="Comentarios adicionales (opcional)"><?= isset($comentarios) ? htmlspecialchars($comentarios) : '' ?></textarea>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn">Enviar Pedido</button>
                        <a href="dashboard.php" class="btn btn-secondary">Volver al Panel</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>

<?php
$conexion->close();
?>
