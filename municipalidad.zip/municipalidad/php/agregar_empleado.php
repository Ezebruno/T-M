<?php
session_start(); // inicia la sesion para acceder a variables de sesion

// Verificar sesión y rol de administrador
if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'admin') { // Si no hay sesión activa o el rol no es 'admin'
    header("HTTP/1.1 403 Forbidden"); // Responde con código 403 (Acceso prohibido)
    exit("Acceso no autorizado"); // Termina la ejecución y muestra un mensaje de error
}

require_once "conexion.php"; // Incluye el archivo para la conexión a la base de datos

$errorMsg = ''; // Inicializa la variable para mensajes de error
$successMsg = ''; // Inicializa la variable para mensajes de éxito

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitizar y validar entradas
    $password = $_POST['contrasena'] ?? '';
    $rol = $_POST['rol'] ?? '';
    $nombre = trim($_POST['nombre'] ?? '');
    $dni = trim($_POST['dni'] ?? '');

    // Validaciones
    if (empty($password) || empty($rol) || empty($nombre) || empty($dni)) {
        $errorMsg = "Todos los campos son obligatorios";
    } elseif (strlen($password) < 8) {
        $errorMsg = "La contraseña debe tener al menos 8 caracteres";
    } elseif (!in_array($rol, ['admin', 'empleado'])) {
        $errorMsg = "Rol no válido";
    } elseif (!preg_match('/^\d{8}$/', $dni)) {
        $errorMsg = "DNI debe tener 8 dígitos";
    } else {
        // Verificar si empleado ya existe
        $stmt = $conexion->prepare("SELECT id FROM empleados WHERE nombre = ? OR dni = ?");
        $stmt->bind_param("ss", $nombre, $dni);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            $errorMsg = "El empleado o DNI ya existe";
        } else {
            // Hash de contraseña
            $hash = password_hash($password, PASSWORD_DEFAULT);
            
            // Consulta simplificada sin fecha_creacion
            $stmt = $conexion->prepare("INSERT INTO empleados (dni, nombre, password, rol) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $dni, $nombre, $hash, $rol);
            
            if ($stmt->execute()) {
                $successMsg = "Empleado agregado exitosamente";
                error_log("Nuevo empleado agregado por admin {$_SESSION['id']}: $nombre");
            } else {
                $errorMsg = "Error al agregar empleado: " . $conexion->error;
            }
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Empleado</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .form-container {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }
        .btn-submit {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #218838;
        }
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .btn-return {
            background-color: #6c757d;
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
            margin-top: 1rem;
        }
        .btn-return:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1><i class="fas fa-user-plus"></i> Agregar Nuevo Empleado</h1>
        
        <?php if ($successMsg): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= htmlspecialchars($successMsg) ?>
                <a href="agregar_empleado.php" style="float:right;">Agregar otro</a>
            </div>
        <?php endif; ?>
        
        <?php if ($errorMsg): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($errorMsg) ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="nombre">Nombre y Apellido:</label>
                <input type="text" id="nombre" name="nombre" class="form-control" required
                       pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]{4,50}" title="4-50 caracteres alfabéticos"
                       value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label for="dni">DNI:</label>
                <input type="text" id="dni" name="dni" class="form-control" required
                       pattern="\d{8}" title="8 dígitos numéricos"
                       value="<?= htmlspecialchars($_POST['dni'] ?? '') ?>">
            </div>
            
            <div class="form-group">
                <label for="contrasena">Contraseña (mínimo 8 caracteres):</label>
                <input type="password" id="contrasena" name="contrasena" class="form-control" required
                       minlength="8">
            </div>
            
            <div class="form-group">
                <label for="rol">Rol:</label>
                <input type="hidden" id="rol" name="rol" value="empleado">
                <p>Empleado</p> <!-- Mostrar el valor seleccionado -->
            </div>


            
            <button type="submit" class="btn-submit">
                <i class="fas fa-save"></i> Guardar Empleado
            </button>
            <a href="dashboard.php" class="btn-return" style="margin-left: 1rem;">
                <i class="fas fa-arrow-left"></i> Volver al Panel
            </a>
        </form>
    </div>
</body>
</html>
<?php
$conexion->close();
?>