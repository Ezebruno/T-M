<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'empleado' || !isset($_SESSION['dni'])) {
    header("HTTP/1.1 403 Forbidden");
    exit('Acceso no autorizado');
}

require_once "conexion.php";

$uploadDir = realpath(dirname(__FILE__) . '/../certificados');
if ($uploadDir === false) {
    die("No se pudo determinar la ruta base del directorio de certificados.");
}
$uploadDir .= '/';

if (!file_exists($uploadDir)) {
    if (!mkdir($uploadDir, 0755, true)) {
        die("No se pudo crear el directorio de certificados.");
    }
}

if (!is_writable($uploadDir)) {
    die("El directorio no tiene permisos de escritura.");
}

$uploadSuccess = false;
$errorMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] === UPLOAD_ERR_OK) {
        $id = $_SESSION['id'];
        $dni = $_SESSION['dni'];
        $file = $_FILES['archivo'];

        $allowedTypes = ['application/pdf'];
        $maxSize = 5 * 1024 * 1024;

        if (!is_uploaded_file($file['tmp_name'])) {
            $errorMsg = "Archivo no válido.";
        } else {
            $fileType = mime_content_type($file['tmp_name']);
            if (!in_array($fileType, $allowedTypes)) {
                $errorMsg = "Solo se permiten archivos PDF.";
            } elseif ($file['size'] > $maxSize) {
                $errorMsg = "Archivo muy grande. Máximo 5MB.";
            } else {
                $nombreArchivo = 'certificado_' . $dni . '_' . time() . '.pdf';
                $destino = $uploadDir . $nombreArchivo;

                if (move_uploaded_file($file['tmp_name'], $destino)) {
                    $stmt = $conexion->prepare("INSERT INTO certificados (empleado_id, archivo, fecha_envio, aprobado) VALUES (?, ?, NOW(), 0)");
                    if ($stmt) {
                        $stmt->bind_param("is", $id, $nombreArchivo);
                        if ($stmt->execute()) {
                            $uploadSuccess = true;
                        } else {
                            unlink($destino);
                            $errorMsg = "Error al insertar en la base de datos.";
                        }
                        $stmt->close();
                    } else {
                        unlink($destino);
                        $errorMsg = "Error al preparar consulta.";
                    }
                } else {
                    $errorMsg = "Error al mover el archivo al destino.";
                }
            }
        }
    } else {
        $uploadErrors = [
            UPLOAD_ERR_NO_FILE => 'No se seleccionó ningún archivo.',
            UPLOAD_ERR_INI_SIZE => 'Archivo demasiado grande.',
            UPLOAD_ERR_FORM_SIZE => 'Archivo muy grande para el formulario.',
        ];
        $errorCode = $_FILES['archivo']['error'];
        $errorMsg = $uploadErrors[$errorCode] ?? 'Error al subir archivo.';
    }
}

$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir Certificado</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #0f172a;
            color: #f8fafc;
            background-image: url('LOGO T&M.jpeg');
            background-size: contain;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .overlay {
            backdrop-filter: blur(8px);
            background-color: rgba(15, 23, 42, 0.85);
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
            width: 90%;
            max-width: 450px;
            animation: fadeIn 1s ease-out;
        }

        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #e2e8f0;
            font-size: 1.5rem;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        input[type="file"] {
            padding: 12px;
            background-color: #1e293b;
            color: #f1f5f9;
            border: 2px dashed #64748b;
            border-radius: 10px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        input[type="file"]:hover {
            border-color: #38bdf8;
            background-color: #374151;
        }

        button {
            padding: 12px;
            background-color: #38bdf8;
            color: #0f172a;
            font-weight: bold;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: background 0.3s ease;
            font-size: 1rem;
        }

        button:hover {
            background-color: #0ea5e9;
        }

        .message {
            padding: 12px;
            text-align: center;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        .success {
            background-color: #166534;
            color: #bbf7d0;
            font-size: 1.1rem;
        }

        .error {
            background-color: #7f1d1d;
            color: #fecaca;
            font-size: 1.1rem;
        }

        @media (max-width: 600px) {
            .overlay {
                padding: 25px;
            }

            h2 {
                font-size: 1.25rem;
            }

            input[type="file"], button {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="overlay">
        <h2>Subir Certificado</h2>

        <?php if ($uploadSuccess): ?>
            <div class="message success">✅ Archivo subido correctamente.</div>
        <?php elseif ($errorMsg): ?>
            <div class="message error">❌ <?php echo htmlspecialchars($errorMsg); ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">
            <input type="file" name="archivo" accept="application/pdf" required>
            <button type="submit">Subir Certificado</button>
        </form>
    </div>
</body>
</html>