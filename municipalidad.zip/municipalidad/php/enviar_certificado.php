<?php
session_start();

// Redirigir si no está autenticado o no es empleado
if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'empleado') {
    header("Location: ../index.php");
    exit();
}

// Conexión a la base de datos
require_once "conexion.php";

// Constantes
define('UPLOAD_DIR_CERTIFICADOS', '../certificados/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

$empleado_id = $_SESSION['id'];
$mensaje_enviado = false;
$errores = [];
$estado_certificado = null;
$motivo_rechazo = null;
$mensaje = "";

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES["certificado"])) {
    $file = $_FILES["certificado"];

    // Validación
    $extension = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));

    if ($extension !== "pdf") {
        $errores[] = "Solo se permiten archivos PDF.";
    } elseif ($file["size"] > MAX_FILE_SIZE) {
        $errores[] = "El archivo excede el tamaño máximo permitido (5MB).";
    } else {
        // Crear directorio si no existe
        if (!is_dir(UPLOAD_DIR_CERTIFICADOS)) {
            mkdir(UPLOAD_DIR_CERTIFICADOS, 0755, true);
        }

        $nombre_archivo = sprintf(
            "certificado_medico_%d_%d.pdf",
            $empleado_id,
            time()
        );

        $ruta_destino = UPLOAD_DIR_CERTIFICADOS . $nombre_archivo;

        if (move_uploaded_file($file["tmp_name"], $ruta_destino)) {
            $stmt = $conexion->prepare("INSERT INTO certificados (empleado_id, archivo, fecha_envio) VALUES (?, ?, NOW())");
            $stmt->bind_param("is", $empleado_id, $ruta_destino);

            if ($stmt->execute()) {
                $mensaje_enviado = true;
            } else {
                $errores[] = "Error al guardar en la base de datos.";
            }

            $stmt->close();
        } else {
            $errores[] = "Error al subir el archivo.";
        }
    }
}

// Verificar certificado previo
$stmt_check = $conexion->prepare("SELECT aprobado, motivo_rechazo, fecha_envio FROM certificados WHERE empleado_id = ? ORDER BY fecha_envio DESC LIMIT 1");
$stmt_check->bind_param("i", $empleado_id);
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows > 0) {
    $stmt_check->bind_result($estado_certificado, $motivo_rechazo, $fecha_envio);
    $stmt_check->fetch();
}

$stmt_check->close();
$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Enviar Certificado Médico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <style>
        /* Copia del estilo del primer formulario */
        .form-container {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #333;
        }

        input[type="file"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .btn {
            display: inline-block;
            padding: 0.85rem 2.5rem;
            background: #4a6fa5;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }

        .btn:hover {
            background: #3a5a8a;
        }

        .btn-secondary {
            background: #6c757d;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .file-info {
            font-size: 0.875rem;
            color: #666;
            margin-top: 0.5rem;
        }

        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: space-between;
        }

        .form-actions .btn {
            flex: 1;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <h1>Enviar Certificado Médico</h1>
        </header>

        <main class="dashboard-main">
            <div class="form-container">
                <?php if ($mensaje_enviado): ?>
                    <div class="alert alert-success">
                        Certificado enviado correctamente.
                    </div>
                <?php endif; ?>

                <?php if (!empty($errores)): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php foreach ($errores as $error): ?>
                                <li><?= htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if ($estado_certificado !== null): ?>
                    <div class="alert <?= $estado_certificado ? 'alert-success' : 'alert-danger' ?>">
                        <strong>Estado del último certificado:</strong>
                        <?= $estado_certificado ? 'Aprobado' : 'Rechazado' ?>
                        <?php if (!$estado_certificado && $motivo_rechazo): ?>
                            <br><strong>Motivo:</strong> <?= htmlspecialchars($motivo_rechazo) ?>
                        <?php endif; ?>
                        <br><strong>Fecha de envío:</strong> <?= htmlspecialchars($fecha_envio) ?>
                    </div>
                <?php endif; ?>

                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="certificado">Subir certificado médico (PDF)</label>
                        <input type="file" name="certificado" id="certificado" accept=".pdf" required>
                        <p class="file-info">Formato permitido: PDF. Tamaño máximo: 5MB.</p>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn">Enviar Certificado</button>
                        <a href="dashboard.php" class="btn btn-secondary">Volver al Panel</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
