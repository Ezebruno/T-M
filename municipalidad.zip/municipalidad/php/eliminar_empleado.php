<?php
session_start();

// Verificar sesión y rol de administrador
if (!isset($_SESSION['id']) || $_SESSION['rol'] !== 'admin') {
    header("HTTP/1.1 403 Forbidden");
    exit("Acceso no autorizado");
}

require_once "conexion.php";

$errorMsg = '';
$successMsg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['baja_empleado'])) {
    // Validar token CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errorMsg = "Token de seguridad inválido";
    } else {
        // Validar ID del empleado
        $id_empleado = filter_var($_POST['id_empleado'], FILTER_VALIDATE_INT);
        
        if (!$id_empleado) {
            $errorMsg = "ID de empleado inválido";
        } elseif ($id_empleado == $_SESSION['id']) {
            $errorMsg = "No puedes darte de baja a ti mismo";
        } else {
            // Verificar si el empleado existe y está activo
            $stmt = $conexion->prepare("SELECT id FROM empleados WHERE id = ? AND activo = 1");
            $stmt->bind_param("i", $id_empleado);
            $stmt->execute();
            
            if (!$stmt->get_result()->num_rows) {
                $errorMsg = "El empleado no existe o ya está dado de baja";
            } else {
                // Baja lógica (inactivación)
                $stmt = $conexion->prepare("UPDATE empleados SET 
                                          activo = 0, 
                                          fecha_baja = NOW(), 
                                          eliminado_por = ? 
                                          WHERE id = ?");
                $stmt->bind_param("ii", $_SESSION['id'], $id_empleado);
                
                if ($stmt->execute()) {
                    $successMsg = "Empleado dado de baja correctamente";
                    // Registrar acción
                    error_log("Empleado $id_empleado dado de baja por admin {$_SESSION['id']}");
                } else {
                    $errorMsg = "Error al dar de baja al empleado: " . $conexion->error;
                }
            }
            $stmt->close();
        }
    }
}

// Generar token CSRF para el próximo formulario
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

// Obtener lista de empleados activos
$empleados = [];
$stmt = $conexion->prepare("SELECT id, dni, nombre, rol FROM empleados WHERE activo = 1 ORDER BY nombre");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $empleados[] = $row;
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baja de Empleados</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .container {
            max-width: 900px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .alert {
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-warning {
            background-color: #fff3cd;
            color: #856404;
            border: 1px solid #ffeeba;
        }
        .empleados-table {
            width: 100%;
            border-collapse: collapse;
            margin: 1.5rem 0;
        }
        .empleados-table th, 
        .empleados-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .empleados-table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        .empleados-table tr:hover {
            background-color: #f5f5f5;
        }
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            margin-right: 0.5rem;
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .confirmation-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: white;
            padding: 2rem;
            border-radius: 8px;
            width: 500px;
            max-width: 90%;
        }
        .modal-actions {
            margin-top: 1.5rem;
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1><i class="fas fa-user-slash"></i> Dar de Baja Empleados</h1>
        
        <?php if ($successMsg): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?= htmlspecialchars($successMsg) ?>
            </div>
        <?php elseif ($errorMsg): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($errorMsg) ?>
            </div>
        <?php endif; ?>
        
        <?php if (empty($empleados)): ?>
            <div class="alert alert-warning">
                <i class="fas fa-info-circle"></i> No hay empleados activos en este momento.
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i> Selecciona un empleado para darle de baja. No podrá acceder al sistema pero permanecerá en los registros.
            </div>
            
            <table class="empleados-table">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>DNI</th>
                        <th>Rol</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($empleados as $empleado): ?>
                    <tr>
                        <td><?= htmlspecialchars($empleado['nombre']) ?></td>
                        <td><?= htmlspecialchars($empleado['dni']) ?></td>
                        <td><?= htmlspecialchars($empleado['rol']) ?></td>
                        <td>
                            <button class="btn btn-danger btn-baja" 
                                    data-id="<?= $empleado['id'] ?>" 
                                    data-nombre="<?= htmlspecialchars($empleado['nombre']) ?>">
                                <i class="fas fa-user-slash"></i> Dar de baja
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Modal de confirmación -->
        <div id="confirmationModal" class="confirmation-modal">
            <div class="modal-content">
                <h3>Confirmar baja de empleado</h3>
                <p>Estás a punto de dar de baja a: <strong id="empleadoNombre"></strong></p>
                <p>¿Estás seguro que deseas continuar?</p>
        
                <form id="bajaForm" method="POST">
                    <input type="hidden" name="baja_empleado" value="1">
                    <input type="hidden" name="id_empleado" id="modalEmpleadoId">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
                  <div class="modal-actions">
                        <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancelar</button>
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-user-slash"></i> Confirmar Baja
                        </button>
                    </div>
                 </form>
        </div>
</div>

        <?php endif; ?>
        
        <div style="margin-top: 2rem;">
            <a href="dashboard.php" class="btn btn-secondary" style="text-decoration: none;">
                <i class="fas fa-arrow-left"></i> Volver al Panel
            </a>
        </div>
    </div>

    <script>
        // Mostrar modal de confirmación
        document.querySelectorAll('.btn-baja').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const nombre = this.getAttribute('data-nombre');
                
                document.getElementById('empleadoNombre').textContent = nombre;
                document.getElementById('modalEmpleadoId').value = id;
                document.getElementById('confirmationModal').style.display = 'flex';
                document.getElementById('confirmacion').focus();
            });
        });
        
        // Cerrar modal
        function closeModal() {
            document.getElementById('confirmationModal').style.display = 'none';
            document.getElementById('bajaForm').reset();
        }
        
        // Cerrar modal al hacer clic fuera del contenido
        document.getElementById('confirmationModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
    </script>
</body>
</html>
<?php
$conexion->close();
?>