<?php
session_start();

// Regenerar el ID de sesión para prevenir session fixation
session_regenerate_id(true);

// Destruir todas las variables de sesión
$_SESSION = array();

// Si se desea destruir la cookie de sesión también
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
    );
}

// Destruir la sesión
session_destroy();

// Redirigir a la página de login con mensaje de éxito
header("Location: ../index.php?logout=1");
exit();
?>