<?php
session_start();
if (isset($_SESSION['id'])) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>T&M - Registrar</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="shortcut icon" href="img/LOGO T&M.jpg" type="image/x-icon">
</head>
<body>
    <main class="register-container">
        <h1>Crear Cuenta</h1>
        
        <?php if (isset($_GET['error'])): ?>
            <div class="alert error"><?= htmlspecialchars($_GET['error']) ?></div>
        <?php endif; ?>
        
        <?php if (isset($_GET['success'])): ?>
            <div class="alert success">¡Registro exitoso! Ahora puedes iniciar sesión</div>
        <?php endif; ?>
        
        <form action="php/registrar.php" method="post" class="register-form">
            <div class="form-group">
                <label for="dni">DNI:</label>
                <input type="text" id="dni" name="dni" required 
                       pattern="[0-9]{8}" title="Ingrese 8 dígitos numéricos">
            </div>
            
            <div class="form-group">
                <label for="nombre">Nombre y Apellido:</label>
                <input type="text" id="nombre" name="nombre" required>
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required 
                       minlength="6" title="Mínimo 6 caracteres">
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirmar Contraseña:</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            
            <button type="submit" class="btn">Registrarse</button>
        </form>
        
        <p class="login-link">¿Ya tienes cuenta? <a href="index.php">Inicia sesión aquí</a></p>
    </main>
    
    <script>
        // Validación de contraseñas coincidentes
        document.querySelector('.register-form').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Las contraseñas no coinciden');
            }
        });
    </script>
</body>
</html>